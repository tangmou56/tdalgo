#include <math.h>
#include <stdio.h>

int f(int i){
	i=i+2;
	return i;
}