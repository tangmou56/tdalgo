#include <math.h>
#include <stdio.h>

int g(int j){
	float racine;
	racine=sqrt(j);
	return racine;
}