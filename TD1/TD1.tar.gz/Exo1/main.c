#include <math.h>
#include <stdio.h>


int main(){
	int i; 
	int j;
	printf("Saisir i: ");
	scanf("%i",&i);
	printf("Saisir j: ");
	scanf("%i",&j);
	float n;
	n=f(i)*g(j);
	printf("Résultat est %f",n);
	
}