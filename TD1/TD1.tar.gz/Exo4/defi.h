#include<stdio.h>
#define N 50
int compter_occurrences(char car,int taille,char *mot);
int comter_voyelles(int taille,char *mot);