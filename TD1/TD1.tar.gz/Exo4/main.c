#include"defi.h"

void main(){
	int n;
	char mot[N];
	char car='c';
	printf("Saisir le mot : ");
	scanf("%s",mot);
	n=comter_voyelles(N,mot);
	printf("il y a %i voyelles dans ce mot.\n",n);
	
}